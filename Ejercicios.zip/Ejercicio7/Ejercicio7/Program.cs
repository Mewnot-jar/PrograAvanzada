﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio7
{
    class Program
    {
        static void Main(string[] args)
        {
            int cantidad_ninos, cantidad_ninas, alumnos_total, ninos_percent, ninas_percent;

            Console.WriteLine("Ingrese la cantidad de niños: ");
            cantidad_ninos = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese la cantidad de niñas: ");
            cantidad_ninas = Convert.ToInt32(Console.ReadLine());

            alumnos_total = cantidad_ninos + cantidad_ninas;

            ninos_percent = (cantidad_ninos * 100) / alumnos_total;
            ninas_percent = (cantidad_ninas * 100) / alumnos_total;

            Console.WriteLine("El porecentaje de niños es: {0}% y el porcentaje de niñas es: {1}%", ninos_percent, ninas_percent);

            Console.ReadKey();
        }

    }
}
