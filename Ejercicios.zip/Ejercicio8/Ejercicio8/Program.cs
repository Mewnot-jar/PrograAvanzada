﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio8
{
    class Program
    {
        static void Main(string[] args)

        {
            int mes, importe, descuento;

            Console.WriteLine("Ingrese el valor del importe:");
            importe = Convert.ToInt32(Console.ReadLine());
            mes = 0;
            while (mes > 12 || mes < 1)
            {
                Console.WriteLine("Ingrese el mes de compra:");
                Console.WriteLine("1. Enero");
                Console.WriteLine("2. Febrero");
                Console.WriteLine("3. Marzo");
                Console.WriteLine("4. Abril");
                Console.WriteLine("5. Mayo");
                Console.WriteLine("6. Junio");
                Console.WriteLine("7. Julio");
                Console.WriteLine("8. Agosto");
                Console.WriteLine("9. Septiembre");
                Console.WriteLine("10. Octubre");
                Console.WriteLine("11. Noviembre");
                Console.WriteLine("12. Diciembre");
                mes = Convert.ToInt32(Console.ReadLine());
            }
            switch (mes)
            {
                case 10:
                    descuento = (importe * 15) / 100;
                    Console.WriteLine("El valor que debe pagar es: {0}", (importe - descuento));
                    break;
                default:
                    Console.WriteLine("El valor que debe pagar es: {0}", importe);
                    break;
            }
            mes = 0;

            Console.ReadKey();
        }
    }
}
