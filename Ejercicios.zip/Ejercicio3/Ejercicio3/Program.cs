﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.WriteLine("Ingrese el valor 1");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el valor 2");
            num2 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
            {
                Console.WriteLine("El valor 1 es mayor que el valor 2");
            }else if(num1 < num2)
            {
                Console.WriteLine("El valor 2 es mayor que el valor 1");
            }
            else
            {
                Console.WriteLine("Ambos numeros son iguales");
            }
            Console.ReadKey();
        }
    }
}
