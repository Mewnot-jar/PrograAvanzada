﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1;

            Console.WriteLine("Ingrese un numero");
            num1 = Convert.ToInt32(Console.ReadLine());

            if (num1 <= 0)
            {
                Console.WriteLine("Error 9000 = El numero ingresado no puede ser 0 o menor que 0");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Ingrese la potencia que quiere calcular");
                int num2 = Convert.ToInt32(Console.ReadLine());
                double raiz_cuadrada = Math.Sqrt(num1);
                double potencia = Math.Pow(num1, num2);
                Console.WriteLine("La potencia es: {0} y la raiz cuadrada es {1}", potencia, raiz_cuadrada);
                Console.ReadKey(); 
            }
        }
    }
}
