﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1;
            int num2;
            int num3;

            Console.WriteLine("Ingrese el valor 1");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el valor 2");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el valor 3");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 < 0)
            {
                Console.WriteLine("El producto de los 3 valores es {0}", (num1 * num2 * num3));
            }
            else
            {
                Console.WriteLine("La suma de los 3 valores es {0}", (num1 + num2 + num3));
            }
            Console.ReadKey();
        }
    }
}
