﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1;
            int num2 = 0;
            int resultado;

            Console.WriteLine("Ingrese el valor 1");
            num1 = Convert.ToInt32(Console.ReadLine());

            while(num2 == 0)
            {
                Console.WriteLine("Ingrese el valor 2");
                num2 = Convert.ToInt32(Console.ReadLine());
            }

            resultado = num1 + num2;
            Console.WriteLine("La suma es: {0}", resultado);

            resultado = num1 - num2;
            Console.WriteLine("La resta es: {0}", resultado);

            resultado = num1 * num2;
            Console.WriteLine("La multiplicación es: {0}", resultado);

            resultado = num1 / num2;
            Console.WriteLine("La division es: {0}", resultado);

            Console.ReadKey();
            
        }
    }
}
