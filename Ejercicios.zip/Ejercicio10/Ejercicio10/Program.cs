﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0;
            
            while (num1 <= 0)
            {
                Console.WriteLine("Ingrese el numero: ");
                num1 = Convert.ToInt32(Console.ReadLine());
            }
            if ((num1 % 2) == 0)
            {
                Console.WriteLine("El numero es par");
            }
            else
            {
                Console.WriteLine("El numero es impar");
            }
            Console.ReadKey();
        }
    }
}
