﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int var1;
            int var2;
            int varAux;

            Console.WriteLine("Ingrese la variable A");
            var1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese la variable B");
            var2 = Convert.ToInt32(Console.ReadLine());

            varAux = var1;
            var1 = var2;
            var2 = varAux;

            Console.WriteLine("Variable A ahora es {0} y variable B ahora es {1}", var1, var2);

            Console.ReadKey();
            
        }
    }
}
