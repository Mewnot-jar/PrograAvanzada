﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1;
            int num2;
            int num3;

            Console.WriteLine("Ingrese el valor 1:");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el valor 2:");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese el valor 3:");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("El numero {0} es mayor", num1);
            } else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("El numero {0} es mayor", num2);
            }
            else
            {
                Console.WriteLine("El numero {0} es mayor", num3);
            }
            Console.ReadKey();
        }
    }
}
